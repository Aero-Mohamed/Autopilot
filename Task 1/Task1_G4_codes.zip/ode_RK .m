clc
clear All
close All

t1=0;
t2=20;
n=100;
h=(t2-t1)/n;
t=(linspace(t1,t2,n+1))';
y1=zeros(length(t),1);
y2=zeros(length(t),1);
y2(1)=1;
y1(1)=-1;


for n=1:length(t)-1
k1=h*(cos(t(n))+sin(y2(n)));
q1=h*(sin(t(n))+cos(y1(n))+sin(y2(n)));

k2=h*(cos(t(n)+0.5*h)+sin(y2(n)+0.5*k1));
q2=h*(sin(t(n)+0.5*h)+cos(y1(n)+0.5*q1)+sin(y2(n)+0.5*k1));

k3=h*(cos(t(n)+0.5*h)+sin(y2(n)+0.5*k2));
q3=h*(sin(t(n)+0.5*h)+cos(y1(n)+0.5*q2)+sin(y2(n)+0.5*k2));

k4=h*(cos(t(n)+h)+sin(y2(n)+k3));
q4=h*(sin(t(n)+h)+cos(y1(n)+q3)+sin(y2(n)+k3));

y2(n+1)=y2(n)+(1/6)*(k1+2*k2+2*k3+k4);
y1(n+1)=y1(n)+(1/6)*(q1+2*q2+2*q3+q4);
end


figure
hold on
plot(t,y1,'r')
plot(t,y2,'b')
legend({'y(1)','y(2)'},...
'Location','southeast','FontSize',8,'Interpreter','latex')
xlabel('$t$','Interpreter','latex','FontSize',13)
%% Check using ode45
[tv,Yv]=ode45(@sys_fun,[0 20],[-1 1]);
plot(tv,Yv(:,1),'r--','LineWidth',1.5)
plot(tv,Yv(:,2),'k--','LineWidth',1.5)
legend({'y(1)','y(2)','y(1)ode45','y(2)ode45'},...
'Location','southeast','FontSize',8,'Interpreter','latex')
xlabel('$t$','Interpreter','latex','FontSize',13)
function f=sys_fun(t,Y)
f(1,1)=sin(t)+cos(Y(1))+sin(Y(2));
f(2,1)=cos(t)+sin(Y(2));
end